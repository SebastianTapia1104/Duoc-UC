package com.grupo11.magenta.interfaces;

// Archivo: RefreshListener.java
public interface RefreshListener {
    void onRefreshNeeded();
}