package com.sebatapia.computec.interfaces;

public interface Descuento {
    double calcularPrecioFinal(double precioBase);
}