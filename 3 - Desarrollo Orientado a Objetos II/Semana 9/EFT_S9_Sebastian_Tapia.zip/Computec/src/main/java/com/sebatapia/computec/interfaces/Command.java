package com.sebatapia.computec.interfaces;

// Interfaz Command con el método execute() 
public interface Command {
    void execute();
}