package com.sebastian.biblioteca_duoc_uc.Excepciones;

public class LibroNoEncontradoException extends Exception {

    public LibroNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}