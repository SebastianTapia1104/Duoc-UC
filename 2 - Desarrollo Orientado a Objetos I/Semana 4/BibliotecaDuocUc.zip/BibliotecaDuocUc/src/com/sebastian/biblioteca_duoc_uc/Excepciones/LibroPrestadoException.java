package com.sebastian.biblioteca_duoc_uc.Excepciones;

public class LibroPrestadoException extends Exception {

    public LibroPrestadoException(String mensaje) {
        super(mensaje);
    }
}