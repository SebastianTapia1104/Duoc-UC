package com.sebastian.biblioteca_duoc_uc.Excepciones;

public class RutInvalidoException extends Exception {
    public RutInvalidoException(String mensaje) {
        super(mensaje);
    }
}