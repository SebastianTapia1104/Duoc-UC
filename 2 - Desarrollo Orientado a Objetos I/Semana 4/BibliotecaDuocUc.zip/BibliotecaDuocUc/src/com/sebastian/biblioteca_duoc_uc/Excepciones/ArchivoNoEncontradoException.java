package com.sebastian.biblioteca_duoc_uc.Excepciones;

public class ArchivoNoEncontradoException extends Exception {
    public ArchivoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}