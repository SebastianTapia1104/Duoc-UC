package com.grupo11.primesecure;

import com.grupo11.primesecure.modelos.PrimeList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class PrimeSecure {

    private static PrimeList primeList = new PrimeList();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcionPrincipal;
        do {
            mostrarMenu();
            opcionPrincipal = pedirOpcion();
            switch (opcionPrincipal) {
                case 1:
                    testManual();
                    break;
                case 2:
                    testAutomatico();
                    break;
                case 3:
                    System.out.println("Saliendo de la aplicación. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
            System.out.println("\n");
        } while (opcionPrincipal != 3);
        scanner.close(); // Cierra el scanner
    }

    private static void mostrarMenu() {
        System.out.println("----   MENÚ PRINCIPAL PRIME SECURE  ----");
        System.out.println("---- La lista de los números primos ----");
        System.out.println("1. Probar PrimeList manualmente");
        System.out.println("2. Probar PrimeList automáticamente con Threads");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private static int pedirOpcion() {
        try {
            return scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, ingrese un número.");
            scanner.next();
            return -1; // Ppción inválida para siga el bucle
        }
    }

    private static void testManual() {
        System.out.println("\n--- MODO MANUAL DE PRUEBA DE PRIMELIST ---");
        int opcionManual;
        do {
            System.out.println("\n--- Opciones Manuales ---");
            System.out.println("1. Añadir número primo a la lista");
            System.out.println("2. Eliminar un número de la lista (por valor)");
            System.out.println("3. Eliminar un número de la lista (por posición)");
            System.out.println("4. Ver números en la lista");
            System.out.println("5. Ver cantidad de números primos en la lista");
            System.out.println("6. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcionManual = pedirOpcion();
            switch (opcionManual) {
                case 1: // Añadir número
                    System.out.print("Ingrese el número a añadir: ");
                    try {
                        int numToAdd = scanner.nextInt();
                        primeList.add(numToAdd);
                        System.out.println("Número " + numToAdd + " añadido exitosamente.");
                    } catch (InputMismatchException e) {
                        System.err.println("Entrada inválida. Por favor, ingrese un número entero.");
                        scanner.next();
                    } catch (IllegalArgumentException e) {
                        System.err.println("Error al añadir: " + e.getMessage());
                    }
                    break;
                case 2: // Eliminar por valor
                    System.out.print("Ingrese el número (valor) a eliminar: (Eliminará el primer número en la lista en caso de estar repetido) ");
                    try {
                        int numeroBorrado = scanner.nextInt();
                        if (primeList.remove(Integer.valueOf(numeroBorrado))) {
                            System.out.println("Número " + numeroBorrado + " eliminado exitosamente.");
                        } else {
                            System.out.println("El número " + numeroBorrado + " no se encontró en la lista.");
                        }
                    } catch (InputMismatchException e) {
                        System.err.println("Entrada inválida. Por favor, ingrese un número entero.");
                        scanner.next();
                    }
                    break;
                case 3: // Eliminar por índice
                    System.out.print("Ingrese la posición del número a eliminar: ");
                    try {
                        int posicionBorrada = scanner.nextInt();
                        if (posicionBorrada > 0 && posicionBorrada <= primeList.size()) {
                            Integer numeroBorrado = primeList.remove(posicionBorrada - 1);
                            System.out.println("Número " + numeroBorrado + " en el índice " + posicionBorrada + " eliminado exitosamente.");
                        } else {
                            System.out.println("Índice fuera de rango. La lista tiene " + primeList.size() + " elementos.");
                        }
                    } catch (InputMismatchException e) {
                        System.err.println("Entrada inválida. Por favor, ingrese un número entero.");
                        scanner.next();
                    } catch (IndexOutOfBoundsException e) {
                         System.err.println("Error al eliminar por índice: " + e.getMessage());
                    }
                    break;
                case 4: // Ver números (antes era 2)
                    System.out.println("Números en PrimeList: " + primeList);
                    break;
                case 5: // Ver cantidad (antes era 3)
                    System.out.println("Cantidad de números primos en la lista: " + primeList.getPrimesCount());
                    break;
                case 6:
                    System.out.println("Volviendo al menú principal.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcionManual != 6);
    }

    private static void testAutomatico() {
        System.out.println("\n--- MODO AUTOMÁTICO CON THREADS (5 INTENTOS) ---");
        System.out.println("Los hilos simularán una operación de 50-200ms para observar la concurrencia.");
        final int intentos = 5;
        // Array para almacenar los hilos
        Thread[] threads = new Thread[intentos];
        for (int i = 0; i < intentos; i++) {
            // Genera números aleatorios entre 1 y 99
            final int numberToTry = ThreadLocalRandom.current().nextInt(1, 100);
            final int threadId = i + 1;
            threads[i] = new Thread(() -> {
                try {
                    System.out.println("Hilo " + threadId + ": Intentando añadir " + numberToTry + "...");
                    // Simular un tiempo de procesamiento para el hilo
                    long sleepTime = ThreadLocalRandom.current().nextLong(50, 201); // Entre 50 y 200 ms
                    Thread.sleep(sleepTime); 
                    primeList.add(numberToTry);
                    System.out.println("Hilo " + threadId + ": Añadido " + numberToTry + " (primo).");
                } catch (IllegalArgumentException e) {
                    System.err.println("Hilo " + threadId + " (Error): No se pudo añadir " + numberToTry + ". " + e.getMessage());
                } catch (InterruptedException e) {
                    System.err.println("Hilo " + threadId + " (Interrupción): El hilo fue interrumpido durante sleep.");
                    Thread.currentThread().interrupt(); // Restablecer el estado de interrupción
                }
            });
            threads[i].start();
        }
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                System.err.println("Un hilo fue interrumpido durante la espera del join: " + e.getMessage());
                Thread.currentThread().interrupt();
            }
        }
        System.out.println("\nTodos los " + intentos + " hilos han terminado.");
        System.out.println("Números primos finales en la lista: " + primeList);
        System.out.println("Cantidad total de primos añadidos: " + primeList.getPrimesCount());
    }
}