package com.grupo11.primesecure.modelos;

import java.util.ArrayList;

public class PrimeList extends ArrayList<Integer> {
    
    public boolean isPrime (int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public boolean add(Integer num) {
        if (num == null) {
            throw new IllegalArgumentException("No se puede añadir un elemento nulo.");
        }
        if (isPrime(num)) {
            return super.add(num);
        } else {
            throw new IllegalArgumentException("Solo se permiten números primos. El número " + num + " no es primo.");
        }
    }
    
    @Override
    public void add(int index, Integer element) {
        if (element == null) {
            throw new IllegalArgumentException("No se puede añadir un elemento nulo.");
        }
        if (isPrime(element)) {
            super.add(index, element);
        } else {
            throw new IllegalArgumentException("Solo se permiten números primos. El número " + element + " no es primo.");
        }
    }
    
    @Override
    public boolean remove(Object o) {
        System.out.println("Intentando remover: " + o);
        return super.remove(o);
    }

    @Override
    public Integer remove(int index) {
        System.out.println("Intentando remover el elemento en el índice: " + index);
        return super.remove(index);
    }

    public int getPrimesCount() {
        return super.size();
    }
    
}