package com.sebastian.comiccollectorsystem.Excepciones;

public class ComicPrestadoException extends Exception {

    public ComicPrestadoException(String mensaje) {
        super(mensaje);
    }
}