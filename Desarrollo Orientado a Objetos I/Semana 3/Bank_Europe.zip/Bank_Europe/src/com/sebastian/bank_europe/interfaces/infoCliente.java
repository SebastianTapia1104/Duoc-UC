package com.sebastian.bank_europe.interfaces;

// INTERFAZ
public interface infoCliente {
    
    // MÉTODO ABSTRACTO
    void mostrarInformacionCliente();
    
}