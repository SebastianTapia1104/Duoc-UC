package com.sebastiantapia.patronesarquitectonicos.interfaces;

public interface Command {
    void execute();
}