package com.sebastiantapia.patronesarquitectonicos;

import com.sebastiantapia.patronesarquitectonicos.controladores.ControladorMain;

public class PatronesArquitectonicos {

    public static void main(String[] args) {
        ControladorMain controladorMain = new ControladorMain();
        controladorMain.iniciar();
    }
}